from collections import deque

class DataHandler:
    def __init__(self):
        self.data_deque = deque()
        

    def load_data(self, file_path):    # -> deque:
        with open(file_path, "r") as Data_File:
            for line in Data_File.readlines():
                data_deque = deque(line.split("/"))
        
        return data_deque
    
    def write_data(self, file_path, encoding_way, deque_data):
        try:
            with open(file_path, "w", encoding=encoding_way) as Data_File:
                for data in deque_data:
                    Data_File.write(data + "/")
        except IOError:
            print("\n============\nAn error occurred while writing to the file.\n============\n")
            
            