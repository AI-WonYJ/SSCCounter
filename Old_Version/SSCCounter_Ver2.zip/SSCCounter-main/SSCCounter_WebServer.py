#  -*- coding: utf-8 -*-
from fastapi import FastAPI, Request, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime

from Module.data_handler import *

app = FastAPI(docs_url=None, redoc_url=None)
    

count, standard_time, refresh = 0, 0, 0#, temp, hum, lamp
# ============ Function ============
# def check():
#     global count, standard_time, refresh
#     with open("nCnt.txt", "r") as file:
#         for line in file.readlines():
#             info_list = line.split("/")
#             count, standard_time, refresh = map(str, info_list)
#             # count = info_list[0]
#             # standard_time = info_list[1]
Data_Handler = DataHandler()
# info_deque = Data_Handler.load_data("nCnt.txt", "utf8")
# count, standard_time, refresh = map(str, info_deque)

# ============ Machine ============

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
# , count: str, current_time: str, standard_time: str):
async def Page(request: Request):
    # global count, standard_time, refresh#, temp, hum, lamp 
    # check()
    info_deque = Data_Handler.load_data(str("nCnt.txt"))
    count, standard_time, refresh = map(str, info_deque)
    current_time = str(datetime.now() )[0:21]  # 필요한 부분 가공
    print(current_time)
    if int(count) <= 6:
        countable = 1
    else:
        countable = 0
    # FastAPI로 new.html에 변수 값 전달
    return templates.TemplateResponse("index(Ver_8).html", {"request": request, "People_Count": int(count), "Countable": countable, "last_time": current_time, "get_time": current_time, "Get_Time": standard_time})

@app.get("/counter.json")
async def nCnt():
    # global count, standard_time#, temp, hum, lamp 
    # check()
    info_deque = Data_Handler.load_data(str("nCnt.txt"))
    count, standard_time, refresh = map(str, info_deque)
    current_time = str(datetime.now() )[0:21]  # 필요한 부분 가공
    print(count)
    return {"people_count": count, "last_time": current_time, "get_time": standard_time}
