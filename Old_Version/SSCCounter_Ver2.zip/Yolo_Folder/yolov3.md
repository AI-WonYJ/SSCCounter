<h1>Yolov3 다운로드 방법</h1>
<p>1. 다음 링크로 접속한다. https://pjreddie.com/darknet/yolo/ </p>
<p>2. YOLOv3-416의 cfg 파일과 weights 파일을 다운받는다.</p>
<p>3. Yolo_Folder에 두 파일을 넣어준다.</p>